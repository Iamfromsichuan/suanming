<template>

</template>

<script>
    export default {
        name: "all_dashi_qianbao_zhichu"
    }
</script>

<style scoped>

</style>
