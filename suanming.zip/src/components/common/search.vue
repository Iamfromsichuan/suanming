<template>
  <div class="nav-index-search">
    <input type="text" placeholder="查找大师或者问题">
    <img class="search" src="../../../static/images/search.png" height="60" width="72"/>
  </div>
</template>

<script>
    export default {
        name: "search"
    }
</script>

<style scoped>

</style>
