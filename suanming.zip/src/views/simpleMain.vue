<template>
    <router-view></router-view>
</template>
<script>
  export default {
    data(){
      return{
        recod:{
          number1:2000,
          number2:1800,
          cont:2000,
        }
      }
    }
  }
</script>
<style scoped>

</style>
